package game.dice.com.dicegameapp.view;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import game.dice.com.dicegameapp.R;
import game.dice.com.dicegameapp.application.GameController;
import game.dice.com.dicegameapp.domain.Game;

public class PlayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText(this, "play dice", Toast.LENGTH_SHORT).show();
        setContentView(R.layout.activity_play);

        GameController controller = new GameController();
        Game gameResult = new Game();
        controller.playGame();
        int value1= gameResult.getDice1();
        int value2= gameResult.getDice2();
        //Toast.makeText(this, value1, Toast.LENGTH_SHORT).show();

    }
}
